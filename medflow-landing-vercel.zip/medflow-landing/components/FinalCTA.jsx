import { ArrowRight } from "lucide-react";
import Reveal from "./Reveal";

export default function FinalCTA() {
  return (
    <section
      id="final"
      className="relative z-[2] max-w-[1180px] mx-auto px-6 py-24"
    >
      <Reveal
        className="text-center py-[110px] px-6 rounded-[28px] border border-line bg-glass relative overflow-hidden"
        delay={0}
      >
        <div
          className="absolute inset-0 -z-10"
          style={{
            background:
              "radial-gradient(ellipse at center, rgba(168,85,247,0.14), rgba(11,11,11,0) 70%)",
          }}
        />
        <span className="eyebrow mb-[22px]">
          <span className="pulse-dot" /> Comece agora
        </span>
        <h2 className="font-display text-[28px] md:text-[44px] max-w-[680px] mx-auto mt-6 mb-[18px] font-semibold tracking-tight">
          Comece hoje a estudar de forma mais inteligente.
        </h2>
        <p className="text-muted max-w-[480px] mx-auto mb-9 text-base">
          Chega de gastar horas criando material. Tenha acesso a flashcards
          organizados e concentre seu tempo no aprendizado.
        </p>
        <button
          className="btn-primary"
          style={{
            boxShadow:
              "0 0 0 1px rgba(255,255,255,0.1), 0 0 60px -6px rgba(168,85,247,0.8)",
          }}
        >
          <span className="shine" />
          Quero acessar o MedFlow agora
          <ArrowRight size={17} />
        </button>
      </Reveal>
    </section>
  );
}
