export default function Footer() {
  return (
    <footer className="relative z-[2] px-6 pt-[50px] pb-10 border-t border-line mt-20">
      <div className="max-w-[1180px] mx-auto flex justify-between items-center flex-wrap gap-5">
        <div>
          <div className="flex items-center gap-[10px] font-display font-bold text-lg">
            <span className="w-[9px] h-[9px] rounded-[2px] bg-gradient-to-br from-blueNeon to-purpleNeon shadow-[0_0_14px_#3E8BFF]" />
            MedFlow
          </div>
          <div className="text-[12.5px] text-muted mt-1.5">
            © 2026 MedFlow Flashcards. Todos os direitos reservados.
          </div>
        </div>
        <div className="flex gap-7 text-[13.5px] text-muted">
          <a href="#" className="hover:text-ink transition-colors">
            Política de Privacidade
          </a>
          <a href="#" className="hover:text-ink transition-colors">
            Termos de Uso
          </a>
          <a href="#" className="hover:text-ink transition-colors">
            Contato
          </a>
        </div>
      </div>
    </footer>
  );
}
