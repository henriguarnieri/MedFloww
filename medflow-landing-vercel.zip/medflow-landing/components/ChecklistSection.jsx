import { Check } from "lucide-react";
import SectionHead from "./SectionHead";
import Reveal from "./Reveal";

const items = [
  "Flashcards completos",
  "Imagens didáticas",
  "Organização por módulos",
  "Atualizações",
  "Tags inteligentes",
  "Compatibilidade Desktop e Mobile",
];

export default function ChecklistSection() {
  return (
    <section className="relative z-[2] max-w-[1180px] mx-auto px-6 py-24">
      <SectionHead eyebrow="Conteúdo incluso" title="O que você recebe" />
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {items.map((item, i) => (
          <Reveal
            key={item}
            delay={i * 0.05}
            className="flex items-center gap-[14px] px-5 py-[18px] rounded-2xl bg-glass border border-line hover:border-greenNeon/30 hover:bg-greenNeon/[0.04] transition-all"
          >
            <div className="w-[26px] h-[26px] rounded-full bg-greenNeon/10 flex items-center justify-center flex-shrink-0">
              <Check size={14} className="text-greenSoft" />
            </div>
            {item}
          </Reveal>
        ))}
      </div>
    </section>
  );
}
