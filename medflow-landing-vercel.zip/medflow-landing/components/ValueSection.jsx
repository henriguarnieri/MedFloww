import { Zap, BookOpen, BrainCircuit } from "lucide-react";
import SectionHead from "./SectionHead";
import Reveal from "./Reveal";

const items = [
  {
    icon: Zap,
    color: "text-blueSoft",
    title: "Economia de tempo",
    text: "Chega de horas montando cartões. Comece a revisar em minutos.",
  },
  {
    icon: BookOpen,
    color: "text-purpleSoft",
    title: "Organização por disciplinas",
    text: "Conteúdo dividido de forma clara, do jeito que você estuda de verdade.",
  },
  {
    icon: BrainCircuit,
    color: "text-greenSoft",
    title: "Revisão baseada em repetição espaçada",
    text: "Método comprovado para fixar conteúdo a longo prazo.",
  },
];

export default function ValueSection() {
  return (
    <section className="relative z-[2] max-w-[1180px] mx-auto px-6 py-24">
      <SectionHead
        eyebrow="Por que MedFlow"
        title="Seu tempo vale mais do que criar flashcards."
        text="Enquanto muitos estudantes passam horas resumindo aulas e montando cartões, você pode começar a revisar imediatamente. O MedFlow entrega flashcards prontos para que você foque no que realmente importa: aprender."
      />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-[22px]">
        {items.map((item, i) => (
          <Reveal key={item.title} delay={i * 0.08} className="glass-card">
            <div className={`icon-tile ${item.color}`}>
              <item.icon size={20} />
            </div>
            <h3 className="text-[17px] mb-2 font-display font-medium">
              {item.title}
            </h3>
            <p className="text-muted text-[14.5px]">{item.text}</p>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
