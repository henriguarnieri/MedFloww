"use client";

import { useState } from "react";
import { MousePointerClick } from "lucide-react";
import SectionHead from "./SectionHead";
import Reveal from "./Reveal";

export default function FlipCardDemo() {
  const [flipped, setFlipped] = useState(false);

  return (
    <section
      id="demo"
      className="relative z-[2] max-w-[1180px] mx-auto px-6 py-24"
    >
      <SectionHead
        eyebrow="Demonstração"
        title="Veja como um flashcard é apresentado"
        center
      />
      <Reveal className="flex justify-center">
        <div
          className="w-full max-w-[380px] h-[260px] cursor-pointer"
          style={{ perspective: "1400px" }}
          onClick={() => setFlipped((f) => !f)}
        >
          <div
            className="relative w-full h-full transition-transform duration-700"
            style={{
              transformStyle: "preserve-3d",
              transform: flipped ? "rotateY(180deg)" : "rotateY(0deg)",
            }}
          >
            {/* front */}
            <div
              className="absolute inset-0 rounded-[20px] border border-line backdrop-blur-xl flex flex-col justify-center items-center text-center p-8 bg-gradient-to-br from-blueNeon/[0.09] to-white/[0.02]"
              style={{ backfaceVisibility: "hidden" }}
            >
              <span className="font-mono text-[11px] text-muted tracking-wider uppercase mb-4">
                Frente · Anatomia craniofacial
              </span>
              <h3 className="text-[19px] leading-[1.4] font-medium">
                Qual é o principal nervo que emerge pelo forame
                infraorbitário?
              </h3>
            </div>

            {/* back */}
            <div
              className="absolute inset-0 rounded-[20px] border border-line backdrop-blur-xl flex flex-col justify-center items-center text-center p-8 bg-gradient-to-br from-purpleNeon/[0.14] to-white/[0.02]"
              style={{
                backfaceVisibility: "hidden",
                transform: "rotateY(180deg)",
              }}
            >
              <span className="font-mono text-[11px] text-muted tracking-wider uppercase mb-4">
                Verso
              </span>
              <h3 className="text-2xl font-display font-bold gradient-text">
                Nervo infraorbitário (V2)
              </h3>
              <svg
                className="mt-4 opacity-85"
                width="140"
                height="60"
                viewBox="0 0 140 60"
                fill="none"
              >
                <path
                  d="M10 30 Q35 5 60 30 T110 30"
                  stroke="url(#g1)"
                  strokeWidth="2"
                  fill="none"
                />
                <circle cx="10" cy="30" r="3" fill="#7CF0BE" />
                <circle cx="60" cy="30" r="3" fill="#C89BFF" />
                <circle cx="110" cy="30" r="3" fill="#7FB2FF" />
                <defs>
                  <linearGradient id="g1" x1="0" y1="0" x2="140" y2="0">
                    <stop offset="0%" stopColor="#34E29A" />
                    <stop offset="50%" stopColor="#A855F7" />
                    <stop offset="100%" stopColor="#3E8BFF" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>
      </Reveal>
      <div className="mt-[18px] text-center text-muted text-[13px] flex items-center justify-center gap-[6px]">
        <MousePointerClick size={14} /> Clique no card para virar
      </div>
    </section>
  );
}
