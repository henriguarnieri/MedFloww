import { X, Check } from "lucide-react";
import SectionHead from "./SectionHead";
import Reveal from "./Reveal";

const bad = [
  "PDFs enormes",
  "Resumos longos",
  "Conteúdo desorganizado",
  "Revisão passiva",
];

const good = [
  "Flashcards objetivos",
  "Organização inteligente",
  "Aprendizagem ativa",
  "Revisão rápida",
];

export default function CompareSection() {
  return (
    <section className="relative z-[2] max-w-[1180px] mx-auto px-6 py-24">
      <SectionHead eyebrow="Comparação" title="O que diferencia o MedFlow?" />
      <Reveal className="grid grid-cols-1 md:grid-cols-2 rounded-[20px] overflow-hidden border border-line">
        <div className="p-[34px_30px] bg-white/[0.02]">
          <h4 className="font-mono text-xs tracking-wider uppercase text-muted mb-[22px]">
            Outros materiais
          </h4>
          {bad.map((item) => (
            <div
              key={item}
              className="flex items-center gap-3 py-3 border-b border-white/5 last:border-none text-[14.5px]"
            >
              <X size={15} className="text-red-400" /> {item}
            </div>
          ))}
        </div>
        <div className="p-[34px_30px] bg-gradient-to-br from-greenNeon/[0.09] to-blueNeon/[0.05] border-t md:border-t-0 md:border-l border-line">
          <h4 className="font-mono text-xs tracking-wider uppercase text-greenSoft mb-[22px]">
            MedFlow
          </h4>
          {good.map((item) => (
            <div
              key={item}
              className="flex items-center gap-3 py-3 border-b border-white/5 last:border-none text-[14.5px]"
            >
              <Check size={15} className="text-greenSoft" /> {item}
            </div>
          ))}
        </div>
      </Reveal>
    </section>
  );
}
