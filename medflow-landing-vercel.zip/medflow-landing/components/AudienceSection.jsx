import { GraduationCap, NotebookPen, Stethoscope, Award } from "lucide-react";
import SectionHead from "./SectionHead";
import Reveal from "./Reveal";

const items = [
  { icon: GraduationCap, color: "text-blueSoft", title: "Estudantes de Medicina" },
  { icon: NotebookPen, color: "text-purpleSoft", title: "Revisão para provas" },
  { icon: Stethoscope, color: "text-greenSoft", title: "Internato" },
  { icon: Award, color: "text-blueSoft", title: "Preparação para residência" },
];

export default function AudienceSection() {
  return (
    <section className="relative z-[2] max-w-[1180px] mx-auto px-6 py-24">
      <SectionHead eyebrow="Público" title="Para quem é o MedFlow?" />
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-[18px]">
        {items.map((item, i) => (
          <Reveal
            key={item.title}
            delay={i * 0.06}
            className="p-[26px_20px] rounded-2xl bg-glass border border-line text-center hover:border-purpleNeon/35 hover:-translate-y-1 transition-all"
          >
            <div className={`icon-tile mx-auto ${item.color}`}>
              <item.icon size={20} />
            </div>
            <h3 className="text-[15.5px] font-display font-medium">
              {item.title}
            </h3>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
