import Reveal from "./Reveal";

export default function SectionHead({ eyebrow, title, text, center = false }) {
  return (
    <Reveal
      className={`max-w-[640px] mb-14 ${
        center ? "mx-auto text-center" : ""
      }`}
    >
      <span className="eyebrow mb-[18px]">
        <span className="pulse-dot" /> {eyebrow}
      </span>
      <h2 className="font-display text-[26px] md:text-[40px] leading-[1.15] mt-[18px] font-semibold tracking-tight">
        {title}
      </h2>
      {text && (
        <p className="text-muted mt-4 text-base max-w-[560px] mx-auto">
          {text}
        </p>
      )}
    </Reveal>
  );
}
