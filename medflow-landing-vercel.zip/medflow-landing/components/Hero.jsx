"use client";

import { motion } from "framer-motion";
import { ArrowRight, Play, Zap, Layers } from "lucide-react";

export default function Hero() {
  return (
    <section className="relative z-[2] max-w-[1180px] mx-auto px-6 grid grid-cols-1 md:grid-cols-[1.1fr_0.9fr] gap-[60px] items-center pt-[70px] md:pt-[110px] pb-[90px]">
      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7, ease: "easeOut" }}
      >
        <span className="eyebrow">
          <span className="pulse-dot" /> Feito para estudantes de Medicina
        </span>
        <h1 className="font-display text-[34px] md:text-[58px] leading-[1.06] my-[22px] font-semibold tracking-tight">
          Pare de perder horas{" "}
          <span className="gradient-text">fazendo flashcards.</span>
        </h1>
        <p className="text-[17px] text-muted max-w-[480px] mb-[34px]">
          Transforme suas revisões com flashcards prontos, organizados e
          pensados para estudantes de Medicina que querem aprender mais em
          menos tempo.
        </p>
        <div className="flex flex-wrap items-center gap-[14px]">
          <button className="btn-primary">
            <span className="shine" />
            Quero estudar de forma inteligente
            <ArrowRight size={17} />
          </button>
          <a href="#demo" className="btn-ghost">
            <Play size={14} /> Ver um flashcard
          </a>
        </div>
      </motion.div>

      <div className="relative h-[340px] md:h-[420px] flex items-center justify-center order-first md:order-last">
        <div className="absolute w-[340px] h-[340px] rounded-full blur-[90px] opacity-35 bg-blueNeon -top-10 -left-5" />
        <div className="absolute w-[340px] h-[340px] rounded-full blur-[90px] opacity-35 bg-purpleNeon -bottom-10 -right-2.5" />

        <div className="absolute z-[3] top-[10px] right-[10px] px-[14px] py-[10px] rounded-xl bg-glassStrong border border-line backdrop-blur-xl text-[12.5px] font-semibold flex items-center gap-2 text-greenSoft shadow-[0_0_22px_rgba(52,226,154,0.18)] animate-floaty2">
          <Zap size={14} /> Repetição espaçada
        </div>

        <div className="relative z-[2] w-[300px] md:w-[320px] p-[28px_26px] rounded-[20px] bg-gradient-to-br from-white/[0.06] to-white/[0.015] border border-line backdrop-blur-xl shadow-[0_30px_80px_-20px_rgba(0,0,0,0.7)] animate-floaty">
          <span className="font-mono text-[10.5px] text-blueSoft tracking-wider uppercase">
            Neuroanatomia · Módulo 04
          </span>
          <h4 className="text-[19px] my-[14px] leading-[1.35] font-display font-medium">
            Qual nervo craniano é responsável pela sensibilidade da córnea?
          </h4>
          <div className="flex justify-between items-center mt-[22px] pt-4 border-t border-line">
            <span className="mini-chip">#trigêmeo</span>
            <span className="mini-chip font-mono">12 / 48</span>
          </div>
        </div>

        <div className="absolute z-[3] bottom-[20px] left-0 px-[14px] py-[10px] rounded-xl bg-glassStrong border border-line backdrop-blur-xl text-[12.5px] font-semibold flex items-center gap-2 text-purpleSoft shadow-[0_0_22px_rgba(168,85,247,0.18)] animate-floaty2 [animation-delay:0.6s]">
          <Layers size={14} /> Organizado por módulo
        </div>
      </div>
    </section>
  );
}
