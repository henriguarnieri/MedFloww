import { LayoutGrid, BadgeCheck, Image as ImageIcon, RefreshCw } from "lucide-react";
import SectionHead from "./SectionHead";
import Reveal from "./Reveal";

const items = [
  {
    icon: LayoutGrid,
    color: "text-blueSoft",
    title: "Flashcards organizados",
    text: "Separados por disciplinas, módulos e assuntos.",
  },
  {
    icon: BadgeCheck,
    color: "text-purpleSoft",
    title: "Conteúdo revisado",
    text: "Estrutura clara, objetiva e fácil de memorizar.",
  },
  {
    icon: ImageIcon,
    color: "text-greenSoft",
    title: "Ilustrações didáticas",
    text: "Imagens que facilitam a compreensão e tornam a revisão mais intuitiva.",
  },
  {
    icon: RefreshCw,
    color: "text-blueSoft",
    title: "Compatível com Anki",
    text: "Importe em poucos segundos e comece a estudar.",
  },
];

export default function FeatureGrid() {
  return (
    <section className="relative z-[2] max-w-[1180px] mx-auto px-6 py-24">
      <SectionHead
        eyebrow="Estrutura"
        title="Desenvolvido para quem leva Medicina a sério."
      />
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-[18px]">
        {items.map((item, i) => (
          <Reveal key={item.title} delay={i * 0.06} className="glass-card">
            <div className={`icon-tile ${item.color}`}>
              <item.icon size={20} />
            </div>
            <h3 className="text-[17px] mb-2 font-display font-medium">
              {item.title}
            </h3>
            <p className="text-muted text-[14.5px]">{item.text}</p>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
