import SectionHead from "./SectionHead";
import Reveal from "./Reveal";

export default function DevicesSection() {
  return (
    <section className="relative z-[2] max-w-[1180px] mx-auto px-6 py-24">
      <SectionHead
        eyebrow="Multiplataforma"
        title="Estude em qualquer lugar"
        center
      />
      <Reveal className="flex justify-center items-end gap-0 flex-wrap py-10">
        <div className="hidden md:block relative w-[340px] h-[210px] rounded-t-2xl rounded-b border border-line bg-gradient-to-br from-white/[0.05] to-white/[0.01] backdrop-blur-md shadow-[0_30px_70px_-20px_rgba(0,0,0,0.6)] -mr-5 z-[1]">
          <div className="absolute inset-[10px] rounded-lg bg-gradient-to-br from-blueNeon/10 to-purpleNeon/[0.08] flex items-center justify-center">
            <div className="w-[70%] p-[10px] rounded-lg bg-white/5 border border-line text-[9px] text-muted text-center">
              Cardiologia · Módulo 02
            </div>
          </div>
        </div>
        <div className="relative w-[190px] h-[250px] rounded-[20px] border border-line bg-gradient-to-br from-white/[0.05] to-white/[0.01] backdrop-blur-md shadow-[0_0_60px_-10px_rgba(62,139,255,0.35),0_30px_70px_-20px_rgba(0,0,0,0.6)] z-[2]">
          <div className="absolute inset-[10px] rounded-lg bg-gradient-to-br from-blueNeon/10 to-purpleNeon/[0.08] flex items-center justify-center">
            <div className="w-[70%] p-[10px] rounded-lg bg-white/5 border border-line text-[9px] text-muted text-center">
              Farmacologia · 8/40
            </div>
          </div>
        </div>
        <div className="relative w-[110px] h-[220px] rounded-[22px] border border-line bg-gradient-to-br from-white/[0.05] to-white/[0.01] backdrop-blur-md shadow-[0_30px_70px_-20px_rgba(0,0,0,0.6)] -ml-5 z-[1]">
          <div className="absolute inset-[10px] rounded-lg bg-gradient-to-br from-blueNeon/10 to-purpleNeon/[0.08] flex items-center justify-center">
            <div className="w-[70%] p-[10px] rounded-lg bg-white/5 border border-line text-[9px] text-muted text-center">
              Revisar agora
            </div>
          </div>
        </div>
      </Reveal>
    </section>
  );
}
