export default function Nav() {
  return (
    <header className="sticky top-0 z-50 backdrop-blur-xl bg-bg/60 border-b border-line">
      <nav className="max-w-[1180px] mx-auto px-6 py-[18px] flex items-center justify-between">
        <div className="flex items-center gap-[10px] font-display font-bold text-lg">
          <span className="w-[9px] h-[9px] rounded-[2px] bg-gradient-to-br from-blueNeon to-purpleNeon shadow-[0_0_14px_#3E8BFF]" />
          MedFlow
        </div>
        <a
          href="#final"
          className="px-[18px] py-[9px] rounded-lg text-[13px] font-semibold border border-line bg-glass hover:border-blueSoft hover:shadow-[0_0_18px_rgba(62,139,255,0.35)] transition-all"
        >
          Começar agora
        </a>
      </nav>
    </header>
  );
}
