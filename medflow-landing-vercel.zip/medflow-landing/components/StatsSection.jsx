"use client";

import { useEffect, useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
import SectionHead from "./SectionHead";

function Counter({ target, suffix = "" }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, amount: 0.4 });
  const [value, setValue] = useState(0);

  useEffect(() => {
    if (!inView) return;
    let cur = 0;
    const step = Math.max(1, Math.round(target / 60));
    const tick = () => {
      cur += step;
      if (cur >= target) {
        setValue(target);
      } else {
        setValue(cur);
        requestAnimationFrame(tick);
      }
    };
    tick();
  }, [inView, target]);

  return (
    <span ref={ref}>
      {value.toLocaleString("pt-BR")}
      {suffix}
    </span>
  );
}

const stats = [
  { type: "counter", target: 5000, suffix: "+", label: "conceitos organizados" },
  { type: "static", value: "Ativa", label: "revisão, não passiva" },
  { type: "counter", target: 70, suffix: "%", label: "menos tempo criando resumos" },
  { type: "static", value: "+", label: "eficiência nos estudos" },
];

export default function StatsSection() {
  return (
    <section className="relative z-[2] max-w-[1180px] mx-auto px-6 py-24">
      <SectionHead
        eyebrow="Método"
        title="Por que estudar com flashcards?"
        center
      />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-5 text-center">
        {stats.map((s, i) => (
          <motion.div
            key={s.label}
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.3 }}
            transition={{ duration: 0.6, delay: i * 0.08 }}
          >
            <div className="font-display text-[32px] md:text-[46px] font-bold gradient-text">
              {s.type === "counter" ? (
                <Counter target={s.target} suffix={s.suffix} />
              ) : (
                s.value
              )}
            </div>
            <div className="text-muted text-[13.5px] mt-2">{s.label}</div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
