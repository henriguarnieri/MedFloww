import Nav from "@/components/Nav";
import Hero from "@/components/Hero";
import ValueSection from "@/components/ValueSection";
import FeatureGrid from "@/components/FeatureGrid";
import ChecklistSection from "@/components/ChecklistSection";
import FlipCardDemo from "@/components/FlipCardDemo";
import StatsSection from "@/components/StatsSection";
import AudienceSection from "@/components/AudienceSection";
import CompareSection from "@/components/CompareSection";
import DevicesSection from "@/components/DevicesSection";
import FinalCTA from "@/components/FinalCTA";
import Footer from "@/components/Footer";
import SynapseBackground from "@/components/SynapseBackground";

export default function Home() {
  return (
    <>
      <SynapseBackground />
      <Nav />
      <main>
        <Hero />
        <ValueSection />
        <FeatureGrid />
        <ChecklistSection />
        <FlipCardDemo />
        <StatsSection />
        <AudienceSection />
        <CompareSection />
        <DevicesSection />
        <FinalCTA />
      </main>
      <Footer />
    </>
  );
}
